import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-portal',
  templateUrl: './employee-portal.component.html',
  styleUrls: ['./employee-portal.component.css']
})
export class EmployeePortalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
