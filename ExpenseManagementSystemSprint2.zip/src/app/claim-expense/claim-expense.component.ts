import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-expense',
  templateUrl: './claim-expense.component.html',
  styleUrls: ['./claim-expense.component.css']
})
export class ClaimExpenseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
