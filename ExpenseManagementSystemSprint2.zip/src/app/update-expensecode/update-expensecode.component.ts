import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-expensecode',
  templateUrl: './update-expensecode.component.html',
  styleUrls: ['./update-expensecode.component.css']
})
export class UpdateExpensecodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
