import { Component, OnInit } from '@angular/core';
import { Routes,RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:string;
  password:string;

  constructor() { }


  ngOnInit(): void {
  }

  validate(){
    if(this.username == "admin" && this.password == "admin")
    {
      console.log("welcome")
      //this.router.navigate(['/employee-portal'])
    }
    
  }
}
