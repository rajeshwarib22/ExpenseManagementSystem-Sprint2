import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-expense',
  templateUrl: './search-expense.component.html',
  styleUrls: ['./search-expense.component.css']
})
export class SearchExpenseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
