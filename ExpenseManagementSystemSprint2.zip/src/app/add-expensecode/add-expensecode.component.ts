import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-expensecode',
  templateUrl: './add-expensecode.component.html',
  styleUrls: ['./add-expensecode.component.css']
})
export class AddExpensecodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
