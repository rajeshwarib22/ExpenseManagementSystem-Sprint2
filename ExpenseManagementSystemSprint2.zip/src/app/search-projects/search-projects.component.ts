import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-projects',
  templateUrl: './search-projects.component.html',
  styleUrls: ['./search-projects.component.css']
})
export class SearchProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
