import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-project',
  templateUrl: './update-project.component.html',
  styleUrls: ['./update-project.component.css']
})
export class UpdateProjectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
