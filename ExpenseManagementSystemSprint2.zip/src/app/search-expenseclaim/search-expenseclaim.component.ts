import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-expenseclaim',
  templateUrl: './search-expenseclaim.component.html',
  styleUrls: ['./search-expenseclaim.component.css']
})
export class SearchExpenseclaimComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
